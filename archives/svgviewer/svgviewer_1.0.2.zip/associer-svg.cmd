@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0associer-svg.ps1"
if errorlevel 1 pause
