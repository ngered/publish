# Enregistre la visionneuse SVG comme application pour les .svg (HKCU, sans droits admin),
# puis ouvre les Applications par défaut de Windows pour la choisir en un clic.
# Windows interdit de fixer le choix par défaut par script (clé UserChoice protégée).

$cmd     = Join-Path $PSScriptRoot 'viewer_svg.cmd'
$nom     = 'Visionneuse SVG'
$progId  = 'VisionneuseSVG.svg'
$appKey  = 'HKCU:\Software\VisionneuseSVG'
$classes = 'HKCU:\Software\Classes'

if (-not (Test-Path $cmd)) { throw "Introuvable : $cmd" }

function Set-Default($path, $value) {
    New-Item -Path $path -Force | Out-Null
    Set-ItemProperty -Path $path -Name '(default)' -Value $value
}

# 1. ProgId : comment ouvrir un fichier
Set-Default "$classes\$progId" 'Fichier SVG (Visionneuse SVG)'
Set-Default "$classes\$progId\shell\open\command" "`"$cmd`" `"%1`""

# 2. Proposer ce ProgId dans « Ouvrir avec » pour .svg
New-Item -Path "$classes\.svg\OpenWithProgids" -Force | Out-Null
New-ItemProperty -Path "$classes\.svg\OpenWithProgids" -Name $progId -Value ([byte[]]@()) -PropertyType Binary -Force | Out-Null

# 3. Déclarer l'application pour qu'elle apparaisse dans Paramètres > Applications par défaut
Set-Default "$appKey\Capabilities" ''
Set-ItemProperty "$appKey\Capabilities" -Name ApplicationName        -Value $nom
Set-ItemProperty "$appKey\Capabilities" -Name ApplicationDescription -Value 'Visionneuse SVG avec zoom et déplacement'
New-Item -Path "$appKey\Capabilities\FileAssociations" -Force | Out-Null
Set-ItemProperty "$appKey\Capabilities\FileAssociations" -Name '.svg' -Value $progId
New-Item -Path 'HKCU:\Software\RegisteredApplications' -Force | Out-Null
Set-ItemProperty 'HKCU:\Software\RegisteredApplications' -Name $nom -Value 'Software\VisionneuseSVG\Capabilities'

# Prévenir l'Explorateur du changement d'associations
Add-Type -Namespace Win32 -Name Shell -MemberDefinition '[DllImport("shell32.dll")] public static extern void SHChangeNotify(int e, int f, IntPtr a, IntPtr b);'
[Win32.Shell]::SHChangeNotify(0x08000000, 0, [IntPtr]::Zero, [IntPtr]::Zero)

Write-Host "Application enregistrée. Dans la page qui s'ouvre : choisir « $nom » pour .svg."
Start-Process "ms-settings:defaultapps?registeredAppUser=$([uri]::EscapeDataString($nom))"
