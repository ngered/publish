param([string]$Fichier)

$dossier = $PSScriptRoot
$modele  = Join-Path $dossier 'visionneuse-svg.html'
$html    = [IO.File]::ReadAllText($modele, [Text.Encoding]::UTF8)

if ($Fichier -and (Test-Path -LiteralPath $Fichier)) {
    $b64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes($Fichier))
    $nom = ConvertTo-Json ([IO.Path]::GetFileName($Fichier))
    $inj = "<script>window.PRELOAD={name:$nom,b64:'$b64'};</script>`n"
    $i   = $html.IndexOf('<script>')
    $html = $html.Insert($i, $inj)
}

# Un fichier temporaire par ouverture, pour pouvoir ouvrir plusieurs fenêtres
$tmpDir = Join-Path $env:TEMP 'visionneuse-svg'
New-Item -ItemType Directory -Force $tmpDir | Out-Null
Get-ChildItem $tmpDir -Filter *.html -ErrorAction SilentlyContinue |
    Where-Object LastWriteTime -lt (Get-Date).AddDays(-1) | Remove-Item -Force -ErrorAction SilentlyContinue

$tmp = Join-Path $tmpDir ([Guid]::NewGuid().ToString('N') + '.html')
[IO.File]::WriteAllText($tmp, $html, (New-Object Text.UTF8Encoding($false)))

$uri = ([Uri]$tmp).AbsoluteUri
Start-Process msedge -ArgumentList "--app=$uri"
