# from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication, Qt
# from qgis.PyQt.QtWidgets import QTreeWidgetItem, QTreeWidget

from dataclasses import dataclass
from pydoc import text
from typing import Union

from qgis.core import QgsFeature, QgsRectangle, QgsFeatureRequest, QgsVectorLayer
from qgis.utils import iface
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QTreeWidget, QTreeWidgetItem, QMessageBox
from PyQt5.QtGui import QIcon

@dataclass
class EntityTarget(QTreeWidgetItem):
    """
    Classe représentant une entité cible avec son texte descriptif.
    """
    text_node: str
    feature: QgsFeature
    layer: QgsVectorLayer  # Ajout de la référence à la couche
    
    def __init__(self, text_node: str, feature: QgsFeature, layer: QgsVectorLayer, *args, **kwargs):
        # Appel du constructeur de la classe parent (QTreeWidgetItem)
        super().__init__()       
    
        statut = kwargs.get("statut", 'Err')
        # Initialisation des attributs de l'instance
        self.text_node = f'{statut}: {text_node}'
        self.feature = feature
        self.layer = layer
        
        # Définir le texte du QTreeWidgetItem
        self.setText(0, self.text_node)    
      
    def zoom_and_select(self):
        """
        Zoome et sélectionne l'entité dans la carte.
        """
        if not self.layer:
            return
            
        self.layer.selectByIds([self.feature.id()])
        canvas = iface.mapCanvas()
        bbox = self.feature.geometry().boundingBox()
        margin = max(bbox.width(), bbox.height()) * 0.1
        bbox.grow(margin)
        canvas.setExtent(bbox)
        canvas.refresh()

def get_node_children(node_parent: QTreeWidgetItem):
    rslt = []
    count = node_parent.childCount()
    for i in range(count):
        node_child = node_parent.child(i)
        rslt.append(node_child)
    return rslt    

def get_node_all_children(node_parent: QTreeWidgetItem):
    rslt = []
    node_children = get_node_children(node_parent)
    # Ajouter les enfants directs
    rslt.extend(node_children)
    # Parcourir récursivement les enfants
    for node_child in node_children:
        rslt.extend(get_node_all_children(node_child))
    return rslt

def add_node(tree_widget: QTreeWidget, text_node: str, node_parent: QTreeWidgetItem = None):
    """Ajoute un noeud simple à l'arbre des vérifications."""
    if node_parent is None:
        node_parent = tree_widget.invisibleRootItem()
    child_node = QTreeWidgetItem(node_parent)
    child_node.setText(0, text_node)
    node_parent.addChild(child_node)
    return child_node

def add_node_entity(tree_widget: QTreeWidget, content: Union[EntityTarget, str], node_parent: QTreeWidgetItem = None):
    """
    Ajoute un noeud interactif lié à une entité ou un noeud simple si content est un string.
    
    Args:
        tree_widget: Le widget QTreeWidget
        content: Instance de EntityTarget ou string
        node_parent: Le noeud parent (optionnel)
    """
    # Déterminer le texte à afficher
    text_node = content.text_node if isinstance(content, EntityTarget) else content
    
    # Créer le noeud avec le texte
    child_node = add_node(tree_widget, text_node, node_parent)
    
    # Si c'est une EntityTarget, ajouter l'interaction
    if isinstance(content, EntityTarget):
        child_node.setData(0, Qt.UserRole, content)
        
        # Connecter le signal itemClicked si ce n'est pas déjà fait
        if not hasattr(tree_widget, '_click_handler_connected'):
            tree_widget.itemClicked.connect(lambda item: handle_node_click(item))
            tree_widget._click_handler_connected = True
           # Ajout de l'icône si spécifiée

        if content.feature and not content.feature.geometry().isNull():
            child_node.setIcon(0,QIcon(":/plugins/check_ready/gfx/loupe.png"))
        else:
            child_node.setIcon(0,QIcon(":/plugins/check_ready/gfx/danger.png"))

    return child_node

def add_node_category(tree_widget: QTreeWidget, text_node: str, node_parent: QTreeWidgetItem = None):
    child_node = add_node(tree_widget,text_node,node_parent)
    child_node.setIcon(0,QIcon(":/plugins/check_ready/gfx/param.png"))  
    return child_node

def add_nodes(tv, list_to_add, node_parent):
    for text_node in list_to_add:
        add_node(tv, text_node, node_parent)
        
def add_nodes_entities(tv, list_to_add, node_parent):
    for entity_target in list_to_add:
        add_node_entity(tv, entity_target, node_parent)

def handle_node_click(item: QTreeWidgetItem):
    """Gère le clic sur un noeud."""
    entity_target = item.data(0, Qt.UserRole)
    if isinstance(entity_target, EntityTarget):
        if entity_target.feature and not entity_target.feature.geometry().isNull():
            entity_target.zoom_and_select()
        else: QMessageBox.information(item.treeWidget(), "zoom sur entité", "Impossible de répérer l'entité")