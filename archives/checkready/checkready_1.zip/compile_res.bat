
@echo on

"C:\Program Files\QGIS 3.26.3\OSGeo4W.bat" pyrcc5 -o resources.py resources.qrc

REM "c:\Users\rmartinez\OneDrive - NGE\Documents\Dev\python\Qgis\tools\Scripts\pyrcc5.exe" -o resources.py resources.qrc
REM pyrcc5 -o resources_rc.py resources.qrc

pause
cmd.exe