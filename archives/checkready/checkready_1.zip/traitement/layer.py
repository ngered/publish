# -*- coding: utf-8 -*-

from qgis.core import QgsProject, QgsVectorLayer, QgsFeature
from ..uipy.check_ready_dockwidget import CheckReadyDockWidget
from ..uipy.ui_tools import EntityTarget
import os
from ..tools.xml_tools import get_root_classes_from_xml
from typing import Tuple

class Layers:
    def __init__(
        self,
    ):
        self.dic_layers = {}
        
        # Répertoire du script courant
        current_dir = os.path.dirname(__file__)
        
        # Répertoire parent du script courant
        parent_dir = os.path.abspath(os.path.join(current_dir, '..'))            
        xml_file = os.path.join(parent_dir, "file", "param_couches.xml")
        
        self.required_tables = get_root_classes_from_xml(xml_file)


    def get_layer(self, name: str) -> QgsVectorLayer:
        if name.lower() in self.dic_layers:
            return self.dic_layers[name.lower()]
        return None
    
    def get_layers(self, layers_names: list[str]) -> list[QgsVectorLayer]:
        """
        Retrieves QgsVectorLayer objects whose names match the SQL LIKE patterns.
        
        Args:
            names (list[str]): A list of patterns with SQL LIKE wildcards (%)
            
        Returns:
            list[QgsVectorLayer]: A list of vector layers whose names match the patterns
        """
        import re
        return [layer for pattern in layers_names 
                for layer_name, layer in self.dic_layers.items() 
                if re.match(f"^{pattern.replace('%', '.*')}$", layer_name.lower())]
    
    def load_layer(self, layer_name: str, rslt: list = None) -> bool:
        """
        Charge une couche par son nom, de manière insensible à la casse.
        
        Args:
            layer_name: Nom de la couche à charger
            rslt: Liste pour stocker les messages d'erreur (optionnel)
            
        Returns:
            True si la couche est chargée avec succès, False sinon
        """
        try:
            # Recherche insensible à la casse
            all_layers = QgsProject.instance().mapLayers().values()
            found_layer = None
            
            found_layers = []
            for layer in all_layers:
                if layer.name().lower() == layer_name.lower():
                    found_layers.append(layer)                   
                    
            if len(found_layers) > 0:
                # Stocke la couche dans le dictionnaire avec le nom en minuscules
                self.dic_layers[layer_name.lower()] = found_layers[0]
                # controle si couche en double
                if len(found_layers) > 1:
                    rslt.append(EntityTarget(f"Couche {layer_name} en double",None,None))
                    return False
                return True
            else:
                if rslt is not None:
                    rslt.append(EntityTarget(f"Couche {layer_name} non trouvée",None,None))
                return False
                
        except Exception as e:
            if rslt is not None:
                rslt.append(f"Erreur lors du chargement de {layer_name}: {str(e)}")
            return False
        
    def get_features(self,layers_names:list[str])->list[QgsFeature]:
        rslt = []
        for layer in self.get_layers(layers_names):
            for feat in layer.getFeatures():
                rslt.append(feat)
        return rslt 

    def load_layers(self):
        check = True
        rslt = []     
        for layer_name in self.required_tables:
            check = check * self.load_layer(layer_name.lower(), rslt)
        return rslt
    
    def get_object_values(self,feat: QgsFeature, layer_name:str)->dict:
        rslt = {}
        layer = self.get_layer(layer_name)
        if layer is None:
            return rslt
        for field in layer.fields():
            field_name = field.name()
            rslt[field_name] = feat[field_name]
        return rslt
    

