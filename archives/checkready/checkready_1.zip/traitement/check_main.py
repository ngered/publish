# -*- coding: utf-8 -*-
import os

# from cattrs import ClassValidationError
from .layer import Layers
from .geom_ready import (
    check_layer_not_multipart,
    check_layer_has_duplicates,
    check_bpe_infra,
    check_bpe_cables,
    check_pbo_in_t_zpbo,
    check_only_two_points_intersect_line,
    check_cables_extremites,
    check_polygon_within_polygon,
    check_one_feature_in_vectorlayer,
    check_one_point_within_polygon,
    check_layer_not_geomnull
)
from .attribut import  *
from ..uipy.ui_tools import *
from .CheckValue import Validator
from ..tools.xml_tools import get_root_classes_from_xml


class main:

    def __init__(self, dockwidget_instance):
        self.dockwidget_instance = dockwidget_instance
        self.tv_check = dockwidget_instance.treeView_check
  
    def update_node_target_count(self, node:QTreeWidgetItem):
        """
        Traitement récursif pour maj le texte d'un nœud en ajoutant le nombre d'enfants entre parenthèses.

        Args:
            node: Le nœud à mettre à jour
        """
        base_text = (
            node.text(0).split("(")[0].strip()
        )  # Récupère le texte sans le compteur
        
        if not base_text.startswith('Err:'):
            count = 0
            child:QTreeWidgetItem
            for child in get_node_all_children(node):
                        
                if child.text(0).startswith('Err:'):
                    count+=1
                
                self.update_node_target_count(child) 
            node.setText(0, f"{base_text} ({count})")
            if count>0:
                node.setIcon(0,QIcon(":/plugins/check_ready/gfx/param_red.png"))
            else:
                node.setIcon(0,QIcon(":/plugins/check_ready/gfx/param_green.png"))
 

    def check_layers(self, tv_check):
        node_check = add_node_category(tv_check, "Vérification des couches check")
        
        # Répertoire du script courant
        current_dir = os.path.dirname(__file__)
        
        # Répertoire parent du script courant
        parent_dir = os.path.abspath(os.path.join(current_dir, '..'))            
        xml_file = os.path.join(parent_dir, "file", "param_couches.xml")
       
        lst_layers = get_root_classes_from_xml(xml_file)
        for layer_name in lst_layers:
            rslt = []
            node_layer = add_node_category(tv_check, layer_name, node_check)
            if not self.layers_instance.load_layer(layer_name.lower(), rslt):
                add_nodes_entities(tv_check, rslt, node_layer)
        return node_check
    
    
    def check_geomnull(self, tv_check, node_parent):
        node_check = add_node_category(tv_check, "Geometries nulles", node_parent)
        for layer_name in self.layers_instance.dic_layers:      
            add_nodes_entities(
                tv_check,
                check_layer_not_geomnull(
                    self.layers_instance.dic_layers[layer_name]
                ),node_check)
        # self.update_node_children_count(node_check)
        return node_check


    def check_multiparts(self, tv_check, node_parent):
        node_check = add_node_category(tv_check, "Multipart check", node_parent)
        for layer_name in ["cables", "t_cheminement"]:
            if layer_name in self.layers_instance.dic_layers:
                add_nodes_entities(
                    tv_check,
                    check_layer_not_multipart(
                        self.layers_instance.get_layer(layer_name)
                    ),
                    node_check,
                )
        # self.update_node_children_count(node_check)
        return node_check

    def check_inf_bpe(self, tv_check, node_parent):
        node_check = add_node_category(tv_check, "Bpe/Infra points check", node_parent)
        add_nodes_entities(
            tv_check,
            check_bpe_infra(
                self.layers_instance.get_features(["bpe"]),
                self.layers_instance.get_features(["attaches"]),
                self.layers_instance.get_features(["infra_points%"]),
                self.layers_instance.get_layer("bpe")
            ),
            node_check,
        )
        # self.update_node_children_count(node_check)
        return node_check

    def check_duplicates(self, tv_check, node_parent):
        node_check = add_node_category(tv_check, "Duplicates check", node_parent)
        for layer_name in [
            "cables",
            "t_cheminement",
            "infra_points",
            "infra_points_autres",
            "infra_points_pot",
            "infra_points_chb",
            "bpe",
            "bal",
            "zpbo",
        ]:
            if layer_name in self.layers_instance.dic_layers:
                add_nodes_entities(
                    tv_check,
                    check_layer_has_duplicates(
                        self.layers_instance.dic_layers[layer_name]),
                    node_check
                )

        # self.update_node_children_count(node_check)
        return node_check

    def check_bpe_cab(self, tv_check, node_parent):
        # Vérification des BPE sans cable
        node_check = add_node_category(self.tv_check, "Câbles/bpe check", node_parent)
        add_nodes_entities(
            tv_check,
            check_bpe_cables(
                self.layers_instance.get_layer("bpe"),
                self.layers_instance.get_layer("cables"),
            ),
            node_check,
        )

        # Vérification des cables sans noeud aux extrémités
        add_nodes_entities(
            tv_check,
            check_cables_extremites(
                self.layers_instance.get_features("bpe"),
                self.layers_instance.get_features("bal"),
                self.layers_instance.get_layer("cables"),
            ),
            node_check,
        )
        # self.update_node_children_count(node_check)
        return node_check

    def check_zones(self, tv_check, node_parent):
        # Vérification des points sans t_zpbo
        node_check = add_node_category(tv_check, "Zones check", node_parent)
        add_nodes_entities(
            tv_check,
            check_pbo_in_t_zpbo(
                self.layers_instance.get_layer("bpe"),
                self.layers_instance.get_layer("t_zpbo"),
            ),
            node_check,
        )

        # Vérification des PBO dans t_zpbo
        add_nodes_entities(
            tv_check,
            check_one_point_within_polygon(
                self.layers_instance.get_layer("bpe"),
                self.layers_instance.get_layer("t_zpbo"),
            ),
            node_check,
        )

        # Vérification dest_zpbo dans t_zsro
        test_zsro = check_one_feature_in_vectorlayer(
            self.layers_instance.get_layer("t_zsro")
        )
        if test_zsro:
            add_nodes_entities(
                tv_check,
                check_polygon_within_polygon(
                    self.layers_instance.get_layer("t_zsro"), test_zsro
                ),
                node_check,
            )
        else:
            add_node(
                tv_check,
                "Il faut une et une seule entité dans la couche t_zsro",
                node_check,
            )

        # self.update_node_children_count(node_check)
        return node_check

    def check_tchem(self, tv_check, node_parent):
        # Vérification des t_chem avec plus de 2 infra_points
        # test = check_one_feature_in_vectorlayer(self.layers_instance.get_layer("t_zsro"))
        node_check = add_node_category(tv_check, "t_cheminement check", node_parent)
        add_nodes_entities(
            tv_check,
            check_only_two_points_intersect_line(
                self.layers_instance.get_layers(["infra_points%"]),
                self.layers_instance.get_layer("t_cheminement"),
            ),
            node_check,
        )
        # self.update_node_children_count(node_check)
        return node_check

    def check_fields(self, tv_check, node_parent):  
        """
        Checks the fields of layers against validation rules defined in an XML file.
        Args:
            tv_check (TreeView): The tree view object to which validation results will be added.
            node_parent (TreeNode): The parent node in the tree view for organizing validation results.
        Returns:
            TreeNode: The root node containing the results of the field checks.
        Functionality:
            - Loads validation rules from an XML file located in the parent directory of the script.
            - Iterates through the main classes (layer names) defined in the validation rules.
            - Verifies the existence of each layer and its attributes.
            - Checks the values of attributes in each feature of the layer against the validation rules.
            - Adds nodes to the tree view to represent missing layers, missing attributes, or invalid attribute values.
        """
        # Vérification des champs remplis
        node_check = add_node_category(tv_check, "Valeurs attributaires check")
        
        # Répertoire du script courant
        current_dir = os.path.dirname(__file__)

        # Répertoire parent du script courant
        parent_dir = os.path.abspath(os.path.join(current_dir, '..'))            
        xml_file = os.path.join(parent_dir, "file", "param_attributs.xml")
        
        cv = Validator(xml_file)
        if len(cv.validation_rules) == 0:
            add_node_entity(tv_check, EntityTarget("Règles de controle non trouvées",None,None), node_check)
        
        # parcours des classes/noms de couche présents dans les paramètres
        for layer_name in cv.get_main_classes():            
            node_layer = add_node_category(tv_check, layer_name, node_check)
            # controle existence de la couche               
            layer = self.layers_instance.get_layer(layer_name)
            if not layer:
                add_node_entity(tv_check, 
                                EntityTarget(f"Couche {layer_name} manquante",None,None),
                                node_layer)
                continue
            
            # controle des attributs de la couche à vérifier
            attrs = cv.get_class_attributes(layer_name)            
            for attr in attrs:
                node_attr = add_node_category(tv_check, attr, node_layer)
                # controle de existence du champ dans la couche
                if not check_field_exist(layer, attr):
                    add_node_entity(tv_check,
                                    EntityTarget(f"Couche {layer_name} - champ {attr} manquant",None,None),
                                    node_attr)
                    continue
                # parcours des entités de la couche pour controle valeur du champ
                for feat in layer.getFeatures():
                    value = feat[attr]
                    object_values = self.layers_instance.get_object_values(feat,layer_name)
                    check = cv.validate_by_class(value,layer_name, attr,object_values)         
                    if not check[0]:                
                        add_node_entity(tv_check,
                                        EntityTarget(f"{layer_name}.{attr} (id:{feat.id()}) : valeur '{value}' incorrecte",feat,layer),
                                        node_attr)        
                
        return node_check

    def main_function(self):
        """Fonction principale du plugin."""
        self.tv_check.clear()
        dockwidget_instance = self.dockwidget_instance

        # Instanciation de la classe Layer
        self.layers_instance = Layers()
        dockwidget_instance.progressBar_check.setValue(5)
        node_geometry = add_node_category(self.tv_check, "Geometry check")

        # Chargement des couches
        self.check_layers(self.tv_check)
        
        # Vérification des entités multipart
        self.check_geomnull(self.tv_check, node_geometry)

        # Vérification des entités multipart
        self.check_multiparts(self.tv_check, node_geometry)

        # Vérification des entités en double
        self.check_duplicates(self.tv_check, node_geometry)

        # Vérification des BPE sans INFRA_POINTS
        self.check_inf_bpe(self.tv_check, node_geometry)
        dockwidget_instance.progressBar_check.setValue(25)

        # Vérification BPE/cables
        self.check_bpe_cab(self.tv_check, node_geometry)
        dockwidget_instance.progressBar_check.setValue(50)

        # Vérification des zones
        self.check_zones(self.tv_check, node_geometry)

        # Vérification des t_cheminement
        self.check_tchem(self.tv_check, node_geometry)
        dockwidget_instance.progressBar_check.setValue(75)

        # Vérification des champs
        self.check_fields(self.tv_check, node_geometry)
        dockwidget_instance.progressBar_check.setValue(100)
        
        # maj compteurs
        self.update_node_target_count(self.tv_check.invisibleRootItem())
