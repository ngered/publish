# -*- coding: utf-8 -*-

from asyncio.windows_events import NULL
from qgis.core import QgsVectorLayer, QgsGeometry, QgsFeature, QgsPointXY
from ..uipy.check_ready_dockwidget import CheckReadyDockWidget
from .attribut import check_field_exist
from ..uipy.ui_tools import EntityTarget
from .layer import Layers
from ..tools.geom_tools import GeomTools, geom_tools
msg = CheckReadyDockWidget()

def check_layer_not_multipart(layer) -> list:
    """Check if the layer is multipart."""
    rslt = []
    for feature in geom_tools.check_layer_not_multipart(layer):
        rslt.append(EntityTarget(f"L'entité {feature.id()} de la couche {layer.name()} est multipart",
                feature,layer))
    return rslt

def check_layer_not_geomnull(layer) -> list:
    """Check if the layer has geom null or invalide."""
    rslt = []
    for feature in geom_tools.check_layer_not_geomnull(layer):        
        rslt.append(EntityTarget(f"L'entité {feature.id()} de la couche {layer.name()} est invalide",
                feature,layer))
    return rslt

def check_layer_has_duplicates(layer) -> list:
    """Check if the layer has duplicates."""
    rslt = []
    # Identifier les entités en double
    for feat in geom_tools.check_layer_has_duplicates(layer):  
        rslt.append(
            EntityTarget(
                f"Doublon sur l'entité {feat[0].id()} de la couche {layer.name()}"
            ,feat[0],layer))
            
    return rslt

def check_bpe_infra(bpe_features, att_features, inf_features: list[QgsFeature], layer_target:QgsVectorLayer) -> list:
    """Check if the layer B has no feature of layer A within 2m and is not connected to a line of layer C
    Exemple : BPE sans INFRA_POINTS et sans ATTACHES"""
    rslt = []
    if bpe_features == None or inf_features == None or att_features == None:
        return ["manque couche pour controle infra/bpe"]

    for feat_bpe in bpe_features:
        if feat_bpe.geometry().isNull():
            continue
        feat_overlay = None
        # check superposition inf/bpe
        for feat_inf in inf_features:
            if feat_inf.geometry().isNull():
                continue
            if feat_bpe.geometry().distance(feat_inf.geometry()) < 2:
                feat_overlay = feat_inf
                break
            
        # check liaison inf/bpe avec attache
        if not feat_overlay:           
            for feat_att in att_features:    
                if feat_att.geometry().isNull():                 
                    continue
                feat_touches = False
                for feat_inf in inf_features:                   
                    if geom_tools.has_line_extremites(feat_att, feat_inf, feat_bpe):                        
                        feat_touches = True
                        break                 
                if feat_touches: break
                            
            if feat_touches == False:                       
                rslt.append(
                    EntityTarget(
                        f"L'entité {feat_bpe.id()} de la couche {layer_target.name()} est sans infra ou sans attaches",
                        feat_bpe,layer_target))
                
                # layer_b.select(feat_b.id())
    return rslt

def check_point_line_extremity(layer_point, layer_line) -> list:
    """Check if the point is not connected to a line."""
    rslt = []
    for feat_point in geom_tools.check_point_line_extremity(layer_point, layer_line):
        rslt.append(EntityTarget(f"L'entité {feat_point.id()} de la couche {layer_point.name()} est sans cable"
                ,feat_point,layer_point))            
         
    return rslt

def check_bpe_cables(layer_bpe, layer_cables) -> list:
    """Check if the BPE is not connected to a cable."""
    rslt = []
    if layer_bpe == None or layer_cables == None:
        return ["manque couche pour controle cable/bpe"]    
    for feat_bpe in layer_bpe.getFeatures():
        feat_touches = False
        feat_line:QgsFeature
        for feat_line in layer_cables.getFeatures():
            # if feat_line.id == 12:
            #     print (feat_line.)
            if feat_line.geometry().isNull():
                continue
            if geom_tools.has_line_extremite(feat_line, feat_bpe) or geom_tools.has_line_sommet(feat_line,feat_bpe):
                feat_touches = True
                break
        if not feat_touches:
            rslt.append(
                EntityTarget(
                    f"L'entité {feat_bpe.id()} de la couche {layer_bpe.name()} est sans cable"
                ,feat_bpe,layer_bpe))
    return rslt
    
def check_pbo_in_t_zpbo(layer_pbo, layer_sro) -> list:
    """Check if the point is not in a polygon.
    Exemple : PBO sans t_zpbo"""
    rslt = []
    for feat_point in geom_tools.check_point_in_polygons(layer_pbo, layer_sro):
        rslt.append(
            EntityTarget(
                f"Le PBO {feat_point.id()} de la couche {layer_pbo.name()} n'est pas dans une t_zpbo",
                feat_point,layer_pbo))
                # layer_point.select(feat_point.id())
    return rslt

def check_only_two_points_intersect_line(layers_point:list[QgsVectorLayer], layer_line) -> list:
    """Check if only two points intersect the line  with a tolerance of 0.5m"""
    rslt = []
    if layers_point == None or layer_line == None :
        rslt.append(EntityTarget(f"manque couche pour controle t_cheminement/infra_points",None,None))
        return rslt

    for feat_line,count in geom_tools.check_only_two_points_intersect_line(layers_point, layer_line):
        rslt.append( EntityTarget(f"L'entité {feat_line.id()} de la couche {layer_line.name()} compte {count} infra_points",
                feat_line,layer_line))
  
    return rslt
   
def check_cables_extremites(bpe_features, bal_features, layer_cables) -> list:
    """Check if begining and end of the line intersetcs point_a or point_b with a tolerance of 0.5m
    Exemple : cable qui ne se termine pas sur une boite (A) ou une BAL (B)"""
    rslt = []

    if bpe_features == None or bal_features == None or layer_cables == None:
        rslt.append(EntityTarget(f"manque couche pour controle cable/bpe/bal",None,None))
        return rslt

    for feat_line in layer_cables.getFeatures():
        touch_point = None
        if feat_line.geometry().isNull():
            continue
      
        # Identify start and end point 
        start_xy = geom_tools.get_start_point(feat_line)
        end_xy = geom_tools.get_end_point(feat_line)

        # Start point
        for feat_point in bpe_features:
            if feat_point.geometry().distance(start_xy) < 0.5 or feat_point.geometry().distance(end_xy) < 0.5:
                touch_point = feat_point
                break
        for feat_point in bal_features:
            if feat_point.geometry().distance(start_xy) or feat_point.geometry().distance(end_xy) < 0.5:
                touch_point = feat_point
                bal_features.remove(feat_point)
                break

        if touch_point:
            rslt.append(
                EntityTarget(
                    f"L'entité {feat_line.id()} de la couche {layer_cables.name()} ne se termine pas sur une boite ou une BAL",
                    feat_line,layer_cables
                )
            )
            # layer_line.select(feat_line.id())
    return rslt

def check_polygon_within_polygon(layer_polygon_a: QgsVectorLayer, feat_polygon_b: QgsFeature) -> list:
    """Check if a polygon is within another polygon.
    Exemple : t_zpbo dans t_zsro"""
    rslt = []
    for feat_polygon_a in geom_tools.check_polygon_within_polygon(layer_polygon_a, feat_polygon_b):
        rslt.append(
            EntityTarget(
                f"L'entité {feat_polygon_a.id()} de la couche {layer_polygon_a.name()} n'est pas dans t_zsro",
                feat_polygon_a,layer_polygon_a
            )
        )      
    return rslt

def check_one_feature_in_vectorlayer(layer):
    """Check if there is only one feature in the vector layer. If yes return feature."""
    if layer.featureCount() == 1:
        return layer.getFeature(0)

def check_one_point_within_polygon(layer_point, layer_polygon) -> list:
    """Count points within polygon. If 0 or more than 1 print polygon is wrong."""
    rslt = []
    lst_points = []
    for feat_point in layer_point.getFeatures():
        if feat_point["NOE_TYPE"] == "PBO" or (
            feat_point["NOE_NBLR"] is not None and feat_point["NOE_NBLR"] != "" and feat_point["NOE_NBLR"] != 0
        ): 
            lst_points.append(feat_point)
    
    for feat_polygon, count in geom_tools.check_one_point_within_polygon(lst_points, layer_polygon):
        rslt.append(EntityTarget(
            f"La t_zpbo {feat_polygon.id()} de la couche {layer_polygon.name()} contient {count} PBO",
            feat_polygon,
            layer_polygon
        ))
                 
    return rslt
