# -*- coding: utf-8 -*-
from ..uipy.ui_tools import EntityTarget

def check_field_exist(layer, field_name, **kwargs): 
    """Check if the field exists in the layer. If not try uppercase. If exist return field name."""
    rslt = kwargs.get("rslt", None)   
    if field_name in layer.fields().names():
        return field_name
    elif field_name.lower() in layer.fields().names():
        return field_name.lower()
    else: 
        if rslt is not None:
            rslt.append(
                f"Le champ {field_name} n'existe pas dans la couche {layer.name()}")
        return None



    """Check first for each field if exist (from JSON).
    If exist check if field is filled."""
    if layer is None:
        return  
    rslt = []
    field = self.check_field_exist(layer, field_name,rslt = rslt)
    if field:
        if layer_name == "bpe" and field_name in ("NOE_POSE", "INF_NUM"):
            for feat in layer.getFeatures():           
                if self.check_field_exist(layer, "NOE_TYPE", rslt = rslt):
                    if feat["NOE_TYPE"] == "NRO" and not feat[field] or feat[field] == "":
                        rslt.append(EntityTarget(
                            f"L'entité {feat.id()+1} NRO de la couche {layer.name()} a le champ {field} vide"
                            ,  feat, layer))
                if self.check_field_exist(layer, "NOE_TYPE", rslt = rslt):
                    if (
                        feat["NOE_TYPE"] in ("NRO", "SRO")
                        and not feat[field]
                        or feat[field] == ""
                    ):
                        rslt.append(EntityTarget(
                            f"L'entité {feat.id()+1} NRO ou SRO de la couche {layer.name()} a le champ {field} vide"
                            ,  feat, layer) )
        else:
            for feat in layer.getFeatures():
                if not feat[field] or feat[field] == "":
                    rslt.append(EntityTarget(
                        f"L'entité {feat.id()+1} de la couche {layer.name()} a le champ {field} vide",  feat, layer))
                    # layer.select(feat.id())
    else:
        rslt.append(f"Le champ {field_name} n'existe pas dans la couche {layer.name()}")
    return rslt
