from calendar import c
import xml.etree.ElementTree as ET
from io import StringIO
from qgis.PyQt.QtCore import QVariant

class Validator:
    def __init__(self, xml_content_or_file):
        """
        Initialize the Validator class with validation rules from XML.
        
        Args:
            xml_content_or_file: Either XML content as a string or a path to an XML file
        """
        # Flat dictionary for quick access by path (case-insensitive)
        self.validation_rules = {}
        
        # Hierarchical dictionary structure: class -> attribute -> rules (case-insensitive)
        self.rules_by_class = {}
        
        # Original case mapping for classes and attributes
        self._original_case = {}
        
        self._load_validation_rules(xml_content_or_file)
    
    def _load_validation_rules(self, xml_content_or_file):
        """
        Load validation rules from XML content or file path.
        
        Args:
            xml_content_or_file: Either XML content as a string or a path to an XML file
        """
        try:
            # Check if input is a string (XML content) or a file path
            if isinstance(xml_content_or_file, str) and xml_content_or_file.strip().startswith('<?xml'):
                # It's XML content
                root = ET.fromstring(xml_content_or_file)
            else:
                # It's a file path
                tree = ET.parse(xml_content_or_file)
                root = tree.getroot()
            
            # Navigate through the nested structure
            for section in root:
                section_name = section.tag
                section_name_lower = section_name.lower()
                
                # Store original case
                self._original_case[section_name_lower] = section_name
                self.rules_by_class[section_name_lower] = {}
                
                for category in section:
                    category_name = category.tag
                    category_name_lower = category_name.lower()
                    
                    # Store original case for attribute
                    self._original_case[f"{section_name_lower}.{category_name_lower}"] = category_name
                    
                    # Check if this attribute uses conditional rules
                    has_conditions = False
                    for child in category:
                        if child.tag == 'CONDITION' or child.tag == 'DEFAULT_RULE':
                            has_conditions = True
                            break
                    
                    if has_conditions:
                        # Process conditional rules
                        conditions = []
                        default_rule = None
                        
                        for child in category:
                            if child.tag == 'CONDITION':
                                condition = {
                                    'attribute': child.get('ATTRIBUTE', ''),
                                    'values': self._parse_values(child.get('VALUES', '')),
                                    'operator': child.get('OPERATOR', '='),
                                }
                                
                                # Handle AND conditions
                                if 'AND_ATTRIBUTE' in child.attrib:
                                    condition['and_attribute'] = child.get('AND_ATTRIBUTE', '')
                                    condition['and_values'] = self._parse_values(child.get('AND_VALUES', ''))
                                    condition['and_operator'] = child.get('AND_OPERATOR', '=')
                                
                                # Get the rule inside the condition
                                rule_element = child.find('RULE')
                                if rule_element is not None:
                                    rule = self._extract_rule_attributes(rule_element)
                                    condition['rule'] = rule
                                    
                                conditions.append(condition)
                                
                            elif child.tag == 'DEFAULT_RULE':
                                default_rule = self._extract_rule_attributes(child)
                        
                        # Store the conditional rules
                        key = f"{section_name_lower}.{category_name_lower}"
                        self.validation_rules[key] = {
                            'type': 'conditional',
                            'conditions': conditions,
                            'default_rule': default_rule
                        }
                        
                        # Also store in hierarchical dictionary
                        self.rules_by_class[section_name_lower][category_name_lower] = self.validation_rules[key]
                        
                    else:
                        # Process regular rule (direct attributes)
                        rule = self._extract_rule_attributes(category)
                        
                        # Store in flat dictionary with full path (lowercase for case-insensitivity)
                        key = f"{section_name_lower}.{category_name_lower}"
                        self.validation_rules[key] = {
                            'type': 'simple',
                            'rule': rule
                        }
                        
                        # Store in hierarchical dictionary (lowercase for case-insensitivity)
                        self.rules_by_class[section_name_lower][category_name_lower] = self.validation_rules[key]
            
        except Exception as e:
            print(f"Error parsing XML: {e}")
    
    def _parse_values(self, values_str):
        """Parse a comma-separated string into a list of trimmed values"""
        return [val.strip() for val in values_str.split(',')]
    
    def _extract_rule_attributes(self, element):
        """Extract rule attributes from an XML element"""
        rule = {
            'allowed_values': [],
            'default_value': None,
            'allow_null': True,
            'value_type': None,
            'value_length': None,
            'range': None
        }
        
        # Get VALUES attribute (comma-separated list)
        if 'VALUES' in element.attrib:
            rule['allowed_values'] = self._parse_values(element.get('VALUES', ''))
        
        # Get DEFAULT attribute
        if 'DEFAULT' in element.attrib:
            rule['default_value'] = element.get('DEFAULT')
        
        # Get ALLOW_NULL attribute
        if 'ALLOW_NULL' in element.attrib:
            allow_null_str = element.get('ALLOW_NULL', '1')
            rule['allow_null'] = (allow_null_str.strip() != '0')
        
        # Get VALUE_TYPE attribute
        if 'VALUE_TYPE' in element.attrib:
            rule['value_type'] = element.get('VALUE_TYPE')
        
        # Get VALUE_LENGTH attribute
        if 'VALUE_LENGTH' in element.attrib:
            try:
                rule['value_length'] = int(element.get('VALUE_LENGTH', '0'))
            except ValueError:
                pass
        
        # Get RANGE attribute
        if 'RANGE' in element.attrib:
            rule['range'] = element.get('RANGE')
            
        return rule
    
    def _evaluate_condition(self, condition, object_values):
        """
        Evaluate if a condition is met based on the object's values.
        
        Args:
            condition: Condition dictionary
            object_values: Dictionary of object values
            
        Returns:
            Boolean indicating if the condition is met
        """
        # Primary condition
        attribute = condition['attribute']
        if attribute not in object_values:
            return False
            
        attr_value = str(object_values[attribute])
        values = condition['values']
        operator = condition['operator']
        
        is_valid = self._compare_value(attr_value, values, operator)
        
        # Secondary condition (AND)
        if is_valid and 'and_attribute' in condition:
            and_attribute = condition['and_attribute']
            if and_attribute not in object_values:
                return False
                
            and_value = str(object_values[and_attribute])
            and_values = condition['and_values']
            and_operator = condition['and_operator']
            
            is_valid = self._compare_value(and_value, and_values, and_operator)
        
        return is_valid
    
    def _compare_value(self, value, condition_values, operator):
        """Compare a value using the specified operator"""
        # Map text operators to comparison operations
        if operator == '=' or operator == 'EQ':
            return value in condition_values
        elif operator == '!=' or operator == 'NE':
            return value not in condition_values
        elif operator == '<' or operator == 'LT':
            try:
                num_value = float(value)
                cond_value = float(condition_values[0]) if condition_values else 0
                return num_value < cond_value
            except ValueError:
                return False
        elif operator == '<=' or operator == 'LE':
            try:
                num_value = float(value)
                cond_value = float(condition_values[0]) if condition_values else 0
                return num_value <= cond_value
            except ValueError:
                return False
        elif operator == '>' or operator == 'GT':
            try:
                num_value = float(value)
                cond_value = float(condition_values[0]) if condition_values else 0
                return num_value > cond_value
            except ValueError:
                return False
        elif operator == '>=' or operator == 'GE':
            try:
                num_value = float(value)
                cond_value = float(condition_values[0]) if condition_values else 0
                return num_value >= cond_value
            except ValueError:
                return False
        return False
    
    def _validate_against_rule(self, value, rule):
        """
        Validate a value against a specific rule.
        
        Args:
            value: The value to validate
            rule: Rule dictionary
            
        Returns:
            A tuple (is_valid, message)
        """
        # Check for null values
        if value is None or value == '':
            if rule['allow_null']:
                return True, "Null value is allowed"
            else:            
                return False, "Null value is not allowed"
      
        # Check value type if specified
        if rule['value_type'] is not None:
            if rule['value_type'] == 'STRING':
                # For strings, just ensure it's a string
                if not isinstance(value, str):
                    return False, f"Value '{value}' is not a string"
            elif rule['value_type'] == 'INT' or rule['value_type'] == 'INTEGER':
                if isinstance(value, QVariant):
                    return False, f"Value '{value}' is not an integer"
                try:
                    int(value)
                except ValueError:
                    return False, f"Value '{value}' is not a valid integer"
            elif rule['value_type'] == 'FLOAT' or rule['value_type'] == 'DECIMAL':
                try:
                    float(value)
                except ValueError:
                    return False, f"Value '{value}' is not a valid number"
        
        # Check value length if specified
        if rule['value_length'] is not None:
            if len(str(value)) > rule['value_length']:
                return False, f"Value length exceeds maximum of {rule['value_length']} characters"
        
        # Check range if specified
        if rule['range'] is not None:
            range_parts = rule['range'].split('-')
            if len(range_parts) == 2:
                try:
                    min_val, max_val = float(range_parts[0]), float(range_parts[1])
                    try:
                        num_value = float(value)
                        if num_value < min_val or num_value > max_val:
                            return False, f"Value {value} is outside allowed range {min_val}-{max_val}"
                    except ValueError:
                        return False, f"Cannot validate non-numeric value against range {rule['range']}"
                except ValueError:
                    return False, f"Invalid range format: {rule['range']}"
        
        # Check if value is in allowed values (if specified)
        if rule['allowed_values'] and str(value) not in rule['allowed_values']:
            allowed_str = ', '.join(rule['allowed_values'])
            return False, f"Value '{value}' is not in the allowed values: {allowed_str}"
        
        return True, "Value is valid"
    
    def validate(self, value, category_path, object_values=None):
        """
        Validate a value against the rules for a given category path (case-insensitive).
        
        Args:
            value: The value to validate
            category_path: The category path in format "SECTION.CATEGORY"
            object_values: Dictionary of object values for conditional rules
            
        Returns:
            A tuple (is_valid, message)
        """
        # Convert category path to lowercase for case-insensitive lookup
        category_path_lower = category_path.lower()
 
        if category_path_lower not in self.validation_rules:
            return False, f"Category path '{category_path}' does not exist"
        
        rule_container = self.validation_rules[category_path_lower] 
 
        # Handle simple rules
        if rule_container['type'] == 'simple':
            return self._validate_against_rule(value, rule_container['rule'])
        
        # Handle conditional rules
        elif rule_container['type'] == 'conditional':
       
            # Need object values to evaluate conditions
            if object_values is None:
                return False, "Object values required for conditional validation"            
     
            # Check each condition                     
            for condition in rule_container['conditions']:
                if self._evaluate_condition(condition, object_values):
                    return self._validate_against_rule(value, condition['rule'])
      
            # If no condition matches, use default rule    
            if rule_container['default_rule']:
                return self._validate_against_rule(value, rule_container['default_rule'])
            else:
                return False, "No matching condition and no default rule defined"
        
        return False, "Unknown rule type"
    
    def validate_by_class(self, value, class_name, category_name, object_values=None):
        """
        Validate a value using the class and category names separately (case-insensitive).
        
        Args:
            value: The value to validate
            class_name: The name of the class (e.g., "BPE", "CABLES")
            category_name: The name of the category (e.g., "NOE_TYPE", "CAB_POSE")
            object_values: Dictionary of object values for conditional rules
            
        Returns:
            A tuple (is_valid, message)
        """
        return self.validate(value, f"{class_name}.{category_name}", object_values)
    
    def get_value_or_default(self, value, category_path, object_values=None):
        """
        Return the provided value if valid, otherwise return the default value if available.
        
        Args:
            value: The value to validate
            category_path: The category path in format "SECTION.CATEGORY" (case-insensitive)
            object_values: Dictionary of object values for conditional rules
            
        Returns:
            The validated value, the default value, or None
        """
        is_valid, _ = self.validate(value, category_path, object_values)
        
        if is_valid:
            return value
        
        category_path_lower = category_path.lower()
        if category_path_lower not in self.validation_rules:
            return None
            
        rule_container = self.validation_rules[category_path_lower]
        
        # For simple rules
        if rule_container['type'] == 'simple':
            if rule_container['rule']['default_value']:
                return rule_container['rule']['default_value']
        
        # For conditional rules
        elif rule_container['type'] == 'conditional' and object_values:
            # Find matching condition
            for condition in rule_container['conditions']:
                if self._evaluate_condition(condition, object_values):
                    if condition['rule']['default_value']:
                        return condition['rule']['default_value']
                    break
            
            # If no matching condition, use default rule
            if rule_container['default_rule'] and rule_container['default_rule']['default_value']:
                return rule_container['default_rule']['default_value']
        
        return None
    
    def get_main_classes(self):
        """
        Get a list of all main class names (top-level sections).
        
        Returns:
            A list of main class names in their original case
        """
        return [self._original_case[class_name.lower()] for class_name in sorted(self.rules_by_class.keys(), key=str.lower)]
    
    def get_class_attributes(self, class_name):
        """
        Get a list of all attributes for a specific class (case-insensitive).
        
        Args:
            class_name: The name of the class (e.g., "BPE", "CABLES")
            
        Returns:
            A list of attribute names in their original case or empty list if class doesn't exist
        """
        class_name_lower = class_name.lower()
        if class_name_lower in self.rules_by_class:
            class_attrs = self.rules_by_class[class_name_lower]
            class_prefix = f"{class_name_lower}."
            
            # Return attributes in their original case
            return [self._original_case[f"{class_name_lower}.{attr}"] 
                    for attr in sorted(class_attrs.keys(), key=str.lower)]
        return []
    
    def get_attribute_rules(self, class_name, attribute_name):
        """
        Get the validation rules for a specific attribute of a class (case-insensitive).
        
        Args:
            class_name: The name of the class (e.g., "BPE", "CABLES")
            attribute_name: The name of the attribute (e.g., "NOE_TYPE", "CAB_POSE")
            
        Returns:
            A dictionary of validation rules or None if not found
        """
        class_name_lower = class_name.lower()
        attribute_name_lower = attribute_name.lower()
        
        if class_name_lower in self.rules_by_class and attribute_name_lower in self.rules_by_class[class_name_lower]:
            return self.rules_by_class[class_name_lower][attribute_name_lower]
        return None
    
    def get_available_categories(self):
        """
        Get a list of all available category paths.
        
        Returns:
            A sorted list of category paths in their original case in the format "SECTION.CATEGORY"
        """
        # Get original case paths
        paths = []
        for path_lower in sorted(self.validation_rules.keys(), key=str.lower):
            parts = path_lower.split('.')
            if len(parts) == 2:
                class_lower, attr_lower = parts
                class_orig = self._original_case.get(class_lower, class_lower)
                attr_orig = self._original_case.get(f"{class_lower}.{attr_lower}", attr_lower)
                paths.append(f"{class_orig}.{attr_orig}")
        
        return paths
    
    def get_rules(self, category_path):
        """
        Get the validation rules for a specific category path (case-insensitive).
        
        Args:
            category_path: The category path in format "SECTION.CATEGORY"
            
        Returns:
            A dictionary of validation rules or None if not found
        """
        category_path_lower = category_path.lower()
        return self.validation_rules.get(category_path_lower)


# Example usage
if __name__ == "__main__":
    # You can use this with either XML content as a string or a file path
    xml_file = "o:Qgis/plugin_fibready/sources/attributs.xml"  # Change this to your file path
    
    try:
        # Create an instance of Validator
        validator = Validator(xml_file)
        
        print("Main classes (case-insensitive access):")
        for class_name in validator.get_main_classes():
            print(f"- {class_name}")
            
            # Show attributes for each class
            attrs = validator.get_class_attributes(class_name)
            print(f"  Attributes for {class_name}:")
            for attr in attrs:
                # Get rules for this attribute
                rules_container = validator.get_attribute_rules(class_name, attr)
                
                if rules_container['type'] == 'simple':
                    rules = rules_container['rule']
                    allowed_values = rules.get('allowed_values', [])
                    default_value = rules.get('default_value', '(none)')
                    allow_null = 'Yes' if rules.get('allow_null', True) else 'No'
                    
                    print(f"    {attr}:")
                    if allowed_values:
                        print(f"      Values: {', '.join(allowed_values)}")
                    print(f"      Default: {default_value}")
                    print(f"      Allow null: {allow_null}")
                
                elif rules_container['type'] == 'conditional':
                    print(f"    {attr} (conditional rules):")
                    for i, condition in enumerate(rules_container['conditions']):
                        attr_name = condition['attribute']
                        values = ', '.join(condition['values'])
                        operator = condition['operator']
                        
                        print(f"      Condition {i+1}: When {attr_name} {operator} [{values}]")
                        rule = condition['rule']
                        allowed_values = rule.get('allowed_values', [])
                        if allowed_values:
                            print(f"        Values: {', '.join(allowed_values)}")
                    
                    if rules_container['default_rule']:
                        print("      Default rule (when no condition matches):")
                        default_rule = rules_container['default_rule']
                        allowed_values = default_rule.get('allowed_values', [])
                        if allowed_values:
                            print(f"        Values: {', '.join(allowed_values)}")
            
        print("\n--- Case Insensitivity Test ---")
        print("Trying to access 'BPE.NOE_TYPE' as 'bpe.noe_type'...")
        rules = validator.get_rules("bpe.noe_type")
        if rules:
            print("Success! Rules found regardless of case.")
            if rules['type'] == 'simple':
                allowed_values = rules['rule'].get('allowed_values', [])
                if allowed_values:
                    print(f"Allowed values: {', '.join(allowed_values)}")
        else:
            print("Error: Rules not found.")
            
        print("\n--- Validation Example (Simple Rule) ---")
        class_name = input("Enter class name (case-insensitive, e.g., BPE, CABLES): ")
        
        class_name_lower = class_name.lower()
        class_exists = any(c.lower() == class_name_lower for c in validator.get_main_classes())
        
        if class_exists:
            print(f"Available attributes for {class_name}:")
            for attr in validator.get_class_attributes(class_name):
                print(f"- {attr}")
            
            attr_name = input(f"Enter attribute name for {class_name} (case-insensitive): ")
            value = input(f"Enter value to validate for {class_name}.{attr_name}: ")
            
            if value == '':
                value = None
            
            # Check if this is a conditional rule
            rules_container = validator.get_attribute_rules(class_name, attr_name)
            if rules_container and rules_container['type'] == 'conditional':
                print("\nThis attribute has conditional rules that depend on other attributes.")
                
                # Collect values for conditional validation
                object_values = {}
                
                # Find all conditions attributes needed
                condition_attrs = set()
                for condition in rules_container['conditions']:
                    condition_attrs.add(condition['attribute'])
                    if 'and_attribute' in condition:
                        condition_attrs.add(condition['and_attribute'])
                
                # Ask for values of each condition attribute
                for cond_attr in condition_attrs:
                    cond_value = input(f"Enter value for {cond_attr} (used in condition): ")
                    object_values[cond_attr] = cond_value
                
                is_valid, message = validator.validate_by_class(value, class_name, attr_name, object_values)
                print(f"\nValidation result: {'VALID' if is_valid else 'INVALID'} - {message}")
                
                final_value = validator.get_value_or_default(value, f"{class_name}.{attr_name}", object_values)
                print(f"Final value to use: {final_value or '(none)'}")
            else:
                # Simple rule validation
                is_valid, message = validator.validate_by_class(value, class_name, attr_name)
                print(f"\nValidation result: {'VALID' if is_valid else 'INVALID'} - {message}")
                
                final_value = validator.get_value_or_default(value, f"{class_name}.{attr_name}")
                print(f"Final value to use: {final_value or '(none)'}")
        else:
            print(f"Class '{class_name}' does not exist")
    
    except Exception as e:
        print(f"Error: {e}")
