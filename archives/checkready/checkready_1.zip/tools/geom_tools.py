from collections import namedtuple
from qgis.core import QgsVectorLayer, QgsGeometry, QgsFeature, QgsPointXY

class GeomTools:
    
    def get_start_point(self, feat_line):
        if(feat_line.geometry().isNull()): return None
        return QgsGeometry.fromPointXY(feat_line.geometry().asMultiPolyline()[0][0])

    def get_polyline_points(self,feat_line)->[]:
        rslt = []
        if not feat_line or not isinstance(feat_line,QgsFeature):
            return[]   
            
        geometry = feat_line.geometry()
        if geometry.isNull(): 
            return []
            
        # Pour une géométrie simple (non multi)
        if geometry.isMultipart():
            # Cas d'une géométrie multi-parties (MultiLineString)
            for part_num, part in enumerate(geometry.asMultiPolyline()):            
                for point_num, point in enumerate(part):
                    # Accéder aux coordonnées X et Y de chaque sommet
                    rslt.append(point)
        else:
            # Cas d'une géométrie simple (LineString)
            line = geometry.asPolyline()
            for point_num, point in enumerate(line):
                # Accéder aux coordonnées X et Y de chaque sommet
                rslt.append(point)
                
        return rslt

    def has_line_extremites(self,feat_line,feat_point1,feat_point2, buffer=0.1) -> bool:
        """Check if the line has the two points as extremites."""
        start_xy = self.get_start_point(feat_line)
        end_xy = self.get_end_point(feat_line)
        if (feat_point1.geometry().distance(start_xy) < buffer and feat_point2.geometry().distance(end_xy) < buffer) or (
            feat_point1.geometry().distance(end_xy) < buffer and feat_point2.geometry().distance(start_xy) < buffer
        ):
            return True
        return False

    def has_line_extremite(self,feat_line,feat_point, buffer=0.1) -> bool:
        """Check if the line has the point as extremites."""
        start_xy = self.get_start_point(feat_line)
        end_xy = self.get_end_point(feat_line)
        if feat_point.geometry().distance(start_xy) < buffer or feat_point.geometry().distance(end_xy) < buffer:
            return True
        return False

    def has_line_sommet(self,feat_line, feat_point, buffer=0.1) -> bool:
        """Check if the line has the point on one sommet."""
        if not feat_line or not feat_point or feat_point.geometry().isNull() or feat_line.geometry().isNull():
            return False
        
        # Récupérer les points de la polyligne
        for line_point in self.get_polyline_points(feat_line):
            # Créer une géométrie point pour comparer avec feat_point
            point_geom = QgsGeometry.fromPointXY(line_point)
            if feat_point.geometry().distance(point_geom) < buffer:
                return True
        return False

    def get_end_point(self,feat_line):
        return QgsGeometry.fromPointXY(feat_line.geometry().asMultiPolyline()[0][-1])

    def check_layer_not_multipart(self,layer) -> list:
        """Check if the layer is multipart."""
        rslt = []
        for feature in layer.getFeatures():
            if feature.geometry().isNull(): continue
            if len(feature.geometry().asMultiPolyline()) > 1:
                rslt.append(feature)
        return rslt
    
    def check_layer_not_geomnull(self,layer) -> list:
        """Check if the layer has geom null or invalide."""
        rslt = []
        for feature in layer.getFeatures():
            if feature.geometry().isNull() or not feature.geometry().isGeosValid():
                rslt.append(feature)
        return rslt
    
    def check_layer_has_duplicates(self,layer) -> list:
        """Check if the layer has duplicates."""
        rslt = []
        geoms_dict = {}
        if layer == None:
            print("La couche n'est pas chargée")
        for feature in layer.getFeatures():
            if feature.geometry().isNull(): continue
            geom = feature.geometry().asWkt()
            id = feature.id()

            if geom not in geoms_dict:
                geoms_dict[geom] = []

            geoms_dict[geom].append(feature)

            # Identifier les entités en double
            for feat in geoms_dict.values():
                if len(feat) > 1:
                    rslt.append(feat)
                
        return rslt
    
    def check_point_line_extremity(self,layer_point, layer_line) -> list:
        """Check if the point is not connected to a line."""
        rslt = []
        for feat_point in layer_point.getFeatures():
            if feat_point.geometry().isNull():
                continue
            feat_touches = False
            for feat_line in layer_line.getFeatures():
                if feat_line.geometry().isNull():
                    continue
                if self.has_line_extremite(feat_line, feat_point):
                    break    
                        
            if not feat_touches:
                rslt.append(feat_point)
            
        return rslt

    def check_point_in_polygons(self,layer_point, layer_polygon) -> list:
        """Check si polygones contiennent chacun au moins n points."""
        rslt = []
        for feat_point in layer_point.getFeatures():   
            feat_in = False
            for feat_polygon in layer_polygon.getFeatures():
                # controle validité geométries
                if feat_polygon.geometry().isNull() or feat_point.geometry().isNull():
                    continue
                # controle point dans polygone
                if feat_point.geometry().intersects(feat_polygon.geometry()):
                    feat_in = True
                    break   
                
            if not feat_in:
                rslt.append(feat_point)
                             
        return rslt

    def check_only_two_points_intersect_line(self,layers_point:list[QgsVectorLayer], layer_line,buffer=0.1) -> list[tuple[QgsFeature,int]]:
        """Check if only two points intersect the line  with a tolerance of 0.5m"""
        rslt = []
        if layers_point == None or layer_line == None :
            return []

        for feat_line in layer_line.getFeatures():
            count = 0
            for layer_point in layers_point:
                for feat_point in layer_point.getFeatures():
                    # controle validité geométries
                    if feat_point.geometry().isNull() or feat_line.geometry().isNull():
                        continue
                    # controle intersection entre point et ligne
                    start_xy = self.get_start_point(feat_line)
                    end_xy = self.get_end_point(feat_line)  
                    
                    if (feat_point.geometry().distance(start_xy) < buffer
                        or feat_point.geometry().distance(end_xy) < buffer):   
                        count += 1

                if count != 2:
                    rslt.append((feat_line,count))             
        return rslt

    def check_polygon_within_polygon(self,layer_polygon_a: QgsVectorLayer, feat_polygon_b: QgsFeature) -> list:
        """Check if a polygon is within another polygon.
        Exemple : t_zpbo dans t_zsro"""
        rslt = []
        for feat_polygon_a in layer_polygon_a.getFeatures():
            if not feat_polygon_a.geometry().within(feat_polygon_b.geometry()):
                rslt.append(feat_polygon_a)          
        return rslt

    # def check_one_point_within_polygon(self, layer_point:QgsVectorLayer, layer_polygon:QgsVectorLayer, n:int=1) -> list[tuple[QgsFeature,int]]:
    #     """Count points within polygon. If 0 or more than 1 print polygon is wrong."""
    #     lst_points =[feat for layer in layer_point for feat in layer.getFeatures()]
    #     return self.check_one_point_within_polygon( lst_points,layer_polygon, n)

    
    def check_one_point_within_polygon(self, lst_points:list[QgsFeature],layer_polygon:QgsVectorLayer,n:int=1) -> list[tuple[QgsFeature,int]]:
        """Count points within polygon. If 0 or more than 1 print polygon is wrong."""
        rslt = []
        for feat_polygon in layer_polygon.getFeatures():
            count = 0
            for feat_point in lst_points:
                if feat_point.geometry().intersects(feat_polygon.geometry()):
                    count += 1
                                    
            if count != n:
                rslt.append((feat_polygon,n))

        return rslt

geom_tools = GeomTools()