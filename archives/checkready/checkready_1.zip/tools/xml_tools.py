import xml.etree.ElementTree as ET
import os

def get_root_classes_from_xml(xml_file):
    try:
        # Vérifier si le fichier existe
        if not os.path.isfile(xml_file):
            print( f"Erreur: Le fichier '{xml_file}' n'existe pas.")
            return None
            
        # Essayer d'analyser le fichier XML
        try:
            tree = ET.parse(xml_file)
            root = tree.getroot()
        except ET.ParseError as e:
            print (f"Erreur: XML invalide: {str(e)}")
            return None
        
        # Obtenir les noms des enfants directs de la racine
        first_level_classes = [child.tag for child in root]
        
        # Retourner directement la liste des éléments de premier niveau
        return first_level_classes
    
    except Exception as e:
        print (f"Erreur inattendue: {str(e)}")