class GetVersion:
    """
    Classe pour parser des fichiers contenant des sections définies 
    par des crochets [section_name] et extraire le contenu de chaque section.
    """
    
    def __init__(self, file_path=None):
        """
        Initialise le parser.
        
        Args:
            file_path (str, optional): Chemin vers le fichier à parser
        """
        self.sections = {}
        if file_path:
            self.load_file(file_path)
        else:
            print ('Fichier version non trouvé')
    
    def load_file(self, file_path):
        """
        Charge et parse un fichier.
        
        Args:
            file_path (str): Chemin vers le fichier à parser
            
        Returns:
            dict: Dictionnaire avec les noms de sections comme clés et leur contenu comme valeurs
        """
        self.sections = {}
        current_section = None
        content = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                for line in file:
                    line = line.strip()
                    
                    # Vérifie si la ligne est un en-tête de section
                    if line.startswith('[') and line.endswith(']'):
                        # Sauvegarde de la section précédente si elle existe
                        if current_section is not None:
                            self.sections[current_section] = '\n'.join(content).strip()
                            content = []
                        
                        # Définit la nouvelle section courante
                        current_section = line[1:-1]  # Supprime les crochets
                    
                    # Ajoute le contenu à la section courante
                    elif current_section is not None:
                        content.append(line)
            
            # Sauvegarde de la dernière section
            if current_section is not None and content:
                self.sections[current_section] = '\n'.join(content).strip()
                
            return self.sections
            
        except Exception as e:
            print(f"Erreur lors du chargement du fichier: {e}")
            return {}
    
    def get_section(self, section_name):
        """
        Récupère le contenu d'une section spécifique.
        
        Args:
            section_name (str): Nom de la section à récupérer
            
        Returns:
            str: Contenu de la section ou None si la section n'existe pas
        """
        return self.sections.get(section_name)
    
    def get_all_sections(self):
        """
        Récupère toutes les sections.
        
        Returns:
            dict: Dictionnaire avec les noms de sections comme clés et leur contenu comme valeurs
        """
        return self.sections
    
    def section_exists(self, section_name):
        """
        Vérifie si une section existe.
        
        Args:
            section_name (str): Nom de la section à vérifier
            
        Returns:
            bool: True si la section existe, False sinon
        """
        return section_name in self.sections

    def get_section_names(self):
        """
        Récupère les noms de toutes les sections.
        
        Returns:
            list: Liste des noms de sections
        """
        return list(self.sections.keys())

def get_version_num():
    """
    Fonction utilitaire pour obtenir la version à partir d'un fichier.
    
    Args:
        file_path (str): Chemin vers le fichier à parser
        
    Returns:
        str: Version trouvée ou None si non trouvée
    """
    rslt=''
    import os.path
    
    # Répertoire du script courant
    current_dir = os.path.dirname(__file__)

    # Répertoire parent du script courant
    parent_dir = os.path.abspath(os.path.join(current_dir, '..'))                
    file_path = os.path.join(parent_dir,  "xml_info.txt")
    
    parser = GetVersion(file_path)
    rslt = parser.get_section("version")
    if rslt is None:
        rslt = 'inconnue'
    return rslt


# Exemple d'utilisation
if __name__ == "__main__":
    parser = GetVersion("../xml_info.txt")
    
    # Affiche toutes les sections parsées
    for section, content in parser.get_all_sections().items():
        print(f"[{section}]")
        print(content)
        print("-" * 40)
    
    # Accède à des sections spécifiques
    if parser.section_exists("version"):
        print(f"Version: {parser.get_section('version')}")
    
    if parser.section_exists("changelog"):
        print(f"Changelog entries: {parser.get_section('changelog').count('v')}")